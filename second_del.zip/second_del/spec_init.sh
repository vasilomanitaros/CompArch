#INITIAL RUN
#./build/ARM/gem5.opt -d spec_results/specbzip configs/example/se.py --cpu-type=MinorCPU  --caches --l2cache -c spec_cpu2006/401.bzip2/src/specbzip -o "spec_cpu2006/401.bzip2/data/input.program 10" -I 100000000

#./build/ARM/gem5.opt -d spec_results/specmcf configs/example/se.py --cpu-type=MinorCPU --caches --l2cache -c spec_cpu2006/429.mcf/src/specmcf -o "spec_cpu2006/429.mcf/data/inp.in" -I 100000000

#./build/ARM/gem5.opt -d spec_results/spechmmer configs/example/se.py --cpu-type=MinorCPU --caches --l2cache -c spec_cpu2006/456.hmmer/src/spechmmer -o "--fixed 0 --mean 325 --num 45000 --sd 200 --seed 0 spec_cpu2006/456.hmmer/data/bombesin.hmm" -I 100000000

#./build/ARM/gem5.opt -d spec_results/specsjeng configs/example/se.py --cpu-type=MinorCPU --caches --l2cache -c spec_cpu2006/458.sjeng/src/specsjeng -o "spec_cpu2006/458.sjeng/data/test.txt" -I 100000000

#./build/ARM/gem5.opt -d spec_results/speclibm configs/example/se.py --cpu-type=MinorCPU --caches --l2cache -c spec_cpu2006/470.lbm/src/speclibm -o "20 spec_cpu2006/470.lbm/data/lbm.in 0 1 spec_cpu2006/470.lbm/data/100_100_130_cf_a.of" -I 100000000

#1GHz
#./build/ARM/gem5.opt -d spec_results1GHz/specbzip configs/example/se.py --cpu-type=MinorCPU --cpu-clock=1GHz --caches --l2cache -c spec_cpu2006/401.bzip2/src/specbzip -o "spec_cpu2006/401.bzip2/data/input.program 10" -I 100000000

#./build/ARM/gem5.opt -d spec_results1GHz/specmcf configs/example/se.py --cpu-type=MinorCPU --caches --cpu-clock=1GHz --l2cache -c spec_cpu2006/429.mcf/src/specmcf -o "spec_cpu2006/429.mcf/data/inp.in" -I 100000000

#./build/ARM/gem5.opt -d spec_results1GHz/spechmmer configs/example/se.py --cpu-type=MinorCPU --caches --cpu-clock=1GHz --l2cache -c spec_cpu2006/456.hmmer/src/spechmmer -o "--fixed 0 --mean 325 --num 45000 --sd 200 --seed 0 spec_cpu2006/456.hmmer/data/bombesin.hmm" -I 100000000

#./build/ARM/gem5.opt -d spec_results1GHz/specsjeng configs/example/se.py --cpu-type=MinorCPU --caches --cpu-clock=1GHz --l2cache -c spec_cpu2006/458.sjeng/src/specsjeng -o "spec_cpu2006/458.sjeng/data/test.txt" -I 100000000

#./build/ARM/gem5.opt -d spec_results1GHz/speclibm configs/example/se.py --cpu-type=MinorCPU --caches --cpu-clock=1GHz --l2cache -c spec_cpu2006/470.lbm/src/speclibm -o "20 spec_cpu2006/470.lbm/data/lbm.in 0 1 spec_cpu2006/470.lbm/data/100_100_130_cf_a.of" -I 100000000

#3GHz
#./build/ARM/gem5.opt -d spec_results3GHz/specbzip configs/example/se.py --cpu-type=MinorCPU --cpu-clock=3GHz --caches --l2cache -c spec_cpu2006/401.bzip2/src/specbzip -o "spec_cpu2006/401.bzip2/data/input.program 10" -I 100000000

#./build/ARM/gem5.opt -d spec_results3GHz/specmcf configs/example/se.py --cpu-type=MinorCPU --caches --cpu-clock=3GHz --l2cache -c spec_cpu2006/429.mcf/src/specmcf -o "spec_cpu2006/429.mcf/data/inp.in" -I 100000000

#./build/ARM/gem5.opt -d spec_results3GHz/spechmmer configs/example/se.py --cpu-type=MinorCPU --caches --cpu-clock=3GHz --l2cache -c spec_cpu2006/456.hmmer/src/spechmmer -o "--fixed 0 --mean 325 --num 45000 --sd 200 --seed 0 spec_cpu2006/456.hmmer/data/bombesin.hmm" -I 100000000

#./build/ARM/gem5.opt -d spec_results3GHz/specsjeng configs/example/se.py --cpu-type=MinorCPU --caches --cpu-clock=3GHz --l2cache -c spec_cpu2006/458.sjeng/src/specsjeng -o "spec_cpu2006/458.sjeng/data/test.txt" -I 100000000

#./build/ARM/gem5.opt -d spec_results3GHz/speclibm configs/example/se.py --cpu-type=MinorCPU --caches --cpu-clock=3GHz --l2cache -c spec_cpu2006/470.lbm/src/speclibm -o "20 spec_cpu2006/470.lbm/data/lbm.in 0 1 spec_cpu2006/470.lbm/data/100_100_130_cf_a.of" -I 100000000

#2133 mem speed
./build/ARM/gem5.opt -d spec_resultsMEM/specbzip configs/example/se.py --cpu-type=MinorCPU --mem-type DDR3_2133_8x8  --caches --l2cache -c spec_cpu2006/401.bzip2/src/specbzip -o "spec_cpu2006/401.bzip2/data/input.program 10" -I 100000000

./build/ARM/gem5.opt -d spec_resultsMEM/specmcf configs/example/se.py --cpu-type=MinorCPU --mem-type DDR3_2133_8x8 --caches --l2cache -c spec_cpu2006/429.mcf/src/specmcf -o "spec_cpu2006/429.mcf/data/inp.in" -I 100000000

./build/ARM/gem5.opt -d spec_resultsMEM/spechmmer configs/example/se.py --cpu-type=MinorCPU --mem-type DDR3_2133_8x8 --caches --l2cache -c spec_cpu2006/456.hmmer/src/spechmmer -o "--fixed 0 --mean 325 --num 45000 --sd 200 --seed 0 spec_cpu2006/456.hmmer/data/bombesin.hmm" -I 100000000

./build/ARM/gem5.opt -d spec_resultsMEM/specsjeng configs/example/se.py --cpu-type=MinorCPU --mem-type DDR3_2133_8x8 --caches --l2cache -c spec_cpu2006/458.sjeng/src/specsjeng -o "spec_cpu2006/458.sjeng/data/test.txt" -I 100000000

./build/ARM/gem5.opt -d spec_resultsMEM/speclibm configs/example/se.py --cpu-type=MinorCPU --mem-type DDR3_2133_8x8 --caches --l2cache -c spec_cpu2006/470.lbm/src/speclibm -o "20 spec_cpu2006/470.lbm/data/lbm.in 0 1 spec_cpu2006/470.lbm/data/100_100_130_cf_a.of" -I 100000000
