./build/ARM/gem5.opt -d FibMinor1GHzDDR3 configs/example/se.py --cpu-type=MinorCPU --sys-clock 1GHz --mem-type DDR3_1600_8x8 --caches -c fib -o "20"

./build/ARM/gem5.opt -d FibMinor1GHzDDR4 configs/example/se.py --cpu-type=MinorCPU --sys-clock 1GHz --mem-type DDR4_2400_16x4 --caches -c fib -o "20"

./build/ARM/gem5.opt -d FibMinor2GHzDDR3 configs/example/se.py --cpu-type=MinorCPU --sys-clock 2GHz --mem-type DDR3_1600_8x8 --caches -c fib -o "20"

./build/ARM/gem5.opt -d FibMinor2GHzDDR4 configs/example/se.py --cpu-type=MinorCPU --sys-clock 2GHz --mem-type DDR4_2400_16x4 --caches -c fib -o "20"

./build/ARM/gem5.opt -d FibTiming1GHzDDR3 configs/example/se.py --cpu-type=TimingSimpleCPU --sys-clock 1GHz --mem-type DDR3_1600_8x8 --caches -c fib -o "20"

./build/ARM/gem5.opt -d FibTiming1GHzDDR4 configs/example/se.py --cpu-type=TimingSimpleCPU --sys-clock 1GHz --mem-type DDR4_2400_16x4 --caches -c fib -o "20"

./build/ARM/gem5.opt -d FibTiming2GHzDDR3 configs/example/se.py --cpu-type=TimingSimpleCPU --sys-clock 2GHz --mem-type DDR3_1600_8x8 --caches -c fib -o "20"

./build/ARM/gem5.opt -d FibTiming2GHzDDR4 configs/example/se.py --cpu-type=TimingSimpleCPU --sys-clock 2GHz --mem-type DDR4_2400_16x4 --caches -c fib -o "20"
